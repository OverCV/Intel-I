package examples;

import jade.core.AID;
import jade.core.Agent;
import jade.domain.FIPANames;
import jade.lang.acl.ACLMessage;
import jade.proto.AchieveREInitiator;
 
public class Solicitante extends Agent {
    @Override
    protected void setup() {
        // Se crea el mensaje de consulta.
        ACLMessage mensaje = new ACLMessage(ACLMessage.QUERY_IF);
        mensaje.setProtocol(FIPANames.InteractionProtocol.FIPA_QUERY);
        mensaje.setContent("Tengo la reserva, �verdad?");
 
        AID id = new AID();
        id.setLocalName("Empalme");
        mensaje.addReceiver(id);
 
        // Se a�ade el comportamiento de consulta.
        this.addBehaviour(new ComprobarInitiator(this, mensaje));
    }
 
    class ComprobarInitiator extends AchieveREInitiator {
        public ComprobarInitiator(Agent agente, ACLMessage mensaje) {
            super(agente, mensaje);
        }
 
        @Override
        protected void handleAgree(ACLMessage agree) {
            System.out.printf("%s: La estaci�n %s est� buscando en la Base de Datos.\n", this.myAgent.getLocalName(), agree.getSender().getLocalName());
        }
 
        @Override
        protected void handleRefuse(ACLMessage refuse) {
            System.out.printf("%s: En estos momentos la estaci�n %s no puede atenderme.\n", this.myAgent.getLocalName(), refuse.getSender().getLocalName());
        }
 
        @Override
        protected void handleNotUnderstood(ACLMessage notUnderstood) {
            System.out.printf("%s: La estaci�n %s no entiende el mensaje.\n", this.myAgent.getLocalName(), notUnderstood.getSender().getLocalName());
        }
 
        @Override
        protected void handleInform(ACLMessage inform) {
            System.out.printf("%s: La estaci�n %s informa: %s.\n", this.myAgent.getLocalName(), inform.getSender().getLocalName(), inform.getContent());
        }
 
        @Override
        protected void handleFailure(ACLMessage fallo) {
            System.out.println(this.myAgent.getLocalName() + ": Se ha producido un fallo.");
        }
    }
}
