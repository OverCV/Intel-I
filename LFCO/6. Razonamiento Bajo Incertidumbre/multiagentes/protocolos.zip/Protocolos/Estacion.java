package examples;

import jade.core.Agent;
import jade.domain.FIPANames;
import jade.domain.FIPAAgentManagement.FailureException;
import jade.domain.FIPAAgentManagement.NotUnderstoodException;
import jade.domain.FIPAAgentManagement.RefuseException;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.proto.AchieveREResponder;
 
public class Estacion extends Agent {
 
    protected void setup() {
        System.out.println(this.getLocalName() + ": Estaci�n activa.");
 
        // Filtrado para recibir s�lo mensajes del protocolo FIPA-Query.
        MessageTemplate plantilla = AchieveREResponder.createMessageTemplate(FIPANames.InteractionProtocol.FIPA_QUERY);
 
        this.addBehaviour(new ComprobarResponder(this, plantilla));
    }
 
    class ComprobarResponder extends AchieveREResponder {
        public ComprobarResponder(Agent agente, MessageTemplate plantilla) {
            super(agente, plantilla);
        }
 
        
        protected ACLMessage handleRequest(ACLMessage request)
                throws NotUnderstoodException, RefuseException {
            System.out.printf("%s: Hemos recibido una llamada de %s solicitando informacion sobre su reserva.\n", this.myAgent.getLocalName(), request.getSender().getLocalName());
 
            // Si el solicitante es v�lido se acepta su petici�n.
            if (comprobarSolicitante(request.getSender().getLocalName())) {
                System.out.println(this.myAgent.getLocalName() + ": Espere un momento por favor.");
                ACLMessage agree = request.createReply();
                agree.setPerformative(ACLMessage.AGREE);
                return agree;
            } else {
                System.out.println(this.myAgent.getLocalName() + ": Estaci�n ocupada.");
                throw new RefuseException("Vuelva a llamar m�s tarde");
            }
        }
 
      
        protected ACLMessage prepareResultNotification(ACLMessage request, ACLMessage response) throws FailureException {
            ACLMessage inform = request.createReply();
            inform.setPerformative(ACLMessage.INFORM);
            String retorno = "No dispone de ninguna reserva";
 
            if (comprobarSolicitante(request.getSender().getName()))
                retorno = "S� que tiene alguna reserva realizada";
 
            inform.setContent(retorno);
            return inform;
        }
 
        // M�todo simple de aceptaci�n o rechazo de solicitudes.
        private boolean comprobarSolicitante(String nombre) {
            return (nombre.length() > 2);
        }
    }
}
