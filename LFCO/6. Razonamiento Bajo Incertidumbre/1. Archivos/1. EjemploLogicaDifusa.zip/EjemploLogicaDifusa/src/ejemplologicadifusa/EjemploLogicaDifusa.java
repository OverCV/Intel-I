/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplologicadifusa;

/**
 *
 * @author luisfercastillo
 */


    /**
     * @param args the command line arguments
     */
    
        // TODO code application logic here
        
        

import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.rule.Rule;
import net.sourceforge.jFuzzyLogic.FunctionBlock;

/**
 * Test parsing an FCL file
 * @author pcingola@users.sourceforge.net
 */
public class EjemploLogicaDifusa  {
    public static void main(String[] args) throws Exception {
        // Load from 'FCL' file
        String fileName = "tipper.fcl";
        FIS fis = FIS.load(fileName,true);

        // Error while loading?
        if( fis == null ) { 
            System.err.println("Can't load file: '" + fileName + "'");
            return;
        }
        

        // Show 
      

        // Set inputs
        fis.setVariable("service", 3);
        fis.setVariable("food", 7);

        // Evaluate
        fis.evaluate();

        
        
        // Print ruleSet
        System.out.println(fis);
        System.out.println("Output Value "+ fis.getVariable("tip").getValue());
        
       for (Rule r: fis.getFunctionBlock("service_excellent").getFuzzyRuleBlock("No1").getRules()){
          // System.out.println(r);
       }
        
    }
}
    
    
